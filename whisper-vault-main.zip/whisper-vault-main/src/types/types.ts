export interface Message {
  id: string;
  sender: string;
  content: string;
  timestamp: number;
}
