export const mockThreads = [
  { id: '1', title: 'Ezekiel • Midnight Pact', last: 'The veil is thin…', ts: Date.now() },
  { id: '2', title: 'Selene • Artifact drop', last: 'Delivered.', ts: Date.now() - 900000 }
];
