declare module 'libsodium-wrappers-sumo' {
  import sodium from 'libsodium-wrappers';
  export = sodium;
}
