declare module 'speakeasy';
